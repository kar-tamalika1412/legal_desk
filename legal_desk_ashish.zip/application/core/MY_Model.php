<?php

class MY_Model extends CI_Model{
	public function test1()
	{
		echo "this is test funtion from MY_Model";
	}
}

?>