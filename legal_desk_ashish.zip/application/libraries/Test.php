<?php
class Test{

	

	public function abc(){
		$ci = & get_instance();
		$ci->load->helper('form');
		echo "abc funtion of test library";

	}
		
	
}