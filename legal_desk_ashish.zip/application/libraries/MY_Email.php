<?php
class MY_Email extends CI_Email{
	public function test()
	{
		echo "Test Function Email Library Extension.";
		
	}
}