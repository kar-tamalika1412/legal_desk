<?php
class Abc extends CI_model{
    public function test(){
        echo "hi";
    }
}