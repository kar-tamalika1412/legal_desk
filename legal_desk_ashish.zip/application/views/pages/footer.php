<script type='text/javascript' src="<?php echo base_url('assets/js/custom.js') ?>"></script>
<!--  <footer>
    <div class="footerbg my-5">
    <div class="container">
        <div class="footitem">
        <div class="row">
            <div class="col-md-3">
            <h5 class="text-light">Information </h5>    
            <h6>Blogs</h6>
            <h6>Frequently Asked Questions</h6>
            <h6>Privacy Policy</h6>
            <h6>Terms and Condition</h6>
            <h6>Return Policy</h6>
            <h6>Career</h6>
            </div>
            <div class="col-md-2">
            <h5 class="text-light">Delivery</h5>
            <h6>Delhi</h6>
            <h6>Haryana</h6>
            <h6>Gujrat</h6>
            <h6>Maharashtra</h6>
            <h6>Punjab</h6>
            <h6>Gujrat</h6>
            <h6>Maharashtra</h6>
          
            </div>
           <div class="col-md-7">
            <h5 class="text-center text-light">Contact Details</h5>
            <div class="row">
                <div class="col-md-3">
                    <h5 class="text-center">Follow us</h5>
                    <h6 class="text-center"><i class="fab fa-facebook"></i></h6>
                    <h6 class="text-center"><i class="fab fa-instagram"></i></h6>
                    <h6 class="text-center"><i class="fab fa-twitter"></i></h6>
                    <h6 class="text-center"><i class="fab fa-twitter"></i></h6>
                </div>
                <div class="col-md-5">
                    <h5 class="text-center">Contact us</h5>
                    <h6><i class="fas fa-envelope-open-text"></i> draft@legalmeni.com</h6>
                    <h6><i class="fas fa-phone"></i> 0129-xxxxxxx</h6>
                    <h6><i class="fab fa-whatsapp"></i> +91-9711170867</h6>

                </div>
                <div class="col-md-4">
                <div class="contact-frm">
                <h5 class="text-center">For Enquiry</h5>
<form>
<input type="text" placeholder="Name" required>
<input id="email" type="text" placeholder="email id" required>
<input id="mobile" type="text" placeholder=" Mobile Number" required>
<div class="text-center"><input type="button" onclick="validate()" value="Submit"></div>
</form>

</div>
                </div>


            </div>
            </div> 
            
            </div>
            


        </div>
        </div>
    </div>
    </footer> -->
