<?php
$this->load->view('pages/header');
$this->load->view($main_content);
$this->load->view('pages/footer');